-- Initial database creation
CREATE DATABASE IF NOT EXISTS order_management
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

-- Use the database
USE order_management;

